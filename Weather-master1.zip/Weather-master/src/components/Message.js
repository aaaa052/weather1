import React from "react";

function Message() {
  return (
    <div className="col-md-7 col-sm-7 middle-col p-5">
      <div className="d-flex flex-column px-4">
        <div className="dashboard text-center py-5">
          <h1>Something went wrong!</h1>
        </div>
      </div>
    </div>
  );
}

export default Message;
