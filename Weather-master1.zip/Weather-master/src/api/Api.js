export const geoApiOptions = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': 'd7d6545d91msh80f1c9655e33c24p182d88jsn7045d03f5288',
		'X-RapidAPI-Host': 'wft-geo-db.p.rapidapi.com'
	}
};

export const geoApiUrl = "https://wft-geo-db.p.rapidapi.com/v1/geo/cities?limit=5&minPopulation=100000&namePrefix="

export const OpenWeatherApiUrl = "https://api.openweathermap.org/data/2.5"
export const OpenWeatherApiKey = "80a530ea7806b2bbfa18cb6b9ec04817"